#include "MergeSort.h"

void merge(int* arr, int p, int q, int r)
{
	int left  = q - p + 1;
	int right = r - q;
	int* arrLeft = new int[left + 1];
	int* arrRight = new int[right + 1];
	int i, j;
	for (i = 0;i < left;i++)
		arrLeft[i] = arr[p + i];
	for (j = 0;j < right;j++)
		arrRight[j] = arr[q + j+1];

	arrLeft[left] = INT_MAX;
	arrRight[right] = INT_MAX;
	i = j = 0;

	for (int k = p;k < r+1 ;k++)
		if (arrLeft[i] <= arrRight[j])
		{
			arr[k] = arrLeft[i];
			i++;
		}
		else
		{
			arr[k] = arrRight[j];
			j++;
		}

	delete[] arrLeft;
	delete[] arrRight;

}
void mergeSort(int* arr,int p ,int r)
{
	int q = 0;
	if (p < r)
	{
		q = ((p + r) / 2);
		mergeSort(arr, p, q);
		mergeSort(arr, q+1 , r);
		merge(arr, p, q, r);
	}
	return;

}