#include "Array.h"
// Arr
void Array::setIndex(int i, int element) {

	this->_arr[i] = element;
}
void Array::setN(int n) {
	this->_n = n;
}
void Array::insertionSortArr()
{
	int key, j;
	for (int i = 1;i < this->getN();i++)
	{
		key = this->getIndex(i);
		j = i - 1;
		while (j >= 0 && this->getIndex(j) > key)
		{
			this->setIndex(j + 1, this->getIndex(j));
			j -= 1;
		}
		this->setIndex(j + 1, key);
	}

	return;
}
Array& Array:: operator= (const Array& other) {

	delete[] this->_arr;
	this->setN(other.getN());
	this->_arr = new int[this->getN()];
	for (int i = 0; i < this->getN();i++) {

		this->setIndex(i, other.getIndex(i));
	}
	return *this;
}
void Array::append(int x) {

	int size = this->getN();
	int newSize = 1 + size;
	Array temp(newSize);
	for (int i = 0;i < size;i++)
		temp.setIndex(i, this->getIndex(i));
	temp.setIndex(newSize-1, x);
	*this = temp;

}
Array::Array(const Array& arr)
{
	this->_n = arr.getN();
	this->_arr = new int[arr.getN()];
	for (int i = 0;i < arr.getN();i++)
		this->setIndex(i, arr.getIndex(i));


}
Array :: Array(int n)
{
	this->_n = n;
	if (n > 0) {
		this->_arr = new int[n];
		for (int i = 0; i < n;i++)
			this->_arr[i] = 0;
	}
	else
		this->_arr = NULL;
}
void Array::printArr() const
{
	for (int i = 0;i < this->getN();i++)
		cout << this->getIndex(i) << endl;
}
Array::~Array()
{
	if(this->_arr!=NULL)
		delete[] this->_arr;
}