#pragma once
#include <iostream>
#include <ctime>
using namespace std;

//swap by address.
void swapElements(int* a, int* b);
// part of smaller than the pivot and the other greater.
int partition(int* arr, int p, int r);
// chose pivot randomly.
int randomizedPartition(int* arr, int p, int r);
// quickSort in O(nlogn) in excepted.
void randomizedQuickSort(int* arr, int p, int r);