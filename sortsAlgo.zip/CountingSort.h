#pragma once
#include <iostream>
#include "OrderStatistics.h"

void countingSort(int* arr,int n);