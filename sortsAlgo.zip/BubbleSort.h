#pragma once
#include <iostream>

void bubbleSort(int* arr,int n);

