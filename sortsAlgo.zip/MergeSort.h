#include "BubbleSort.h"
#include "QuickSort.h"
#include "InsertionSort.h"

void mergeSort(int* arr,int p ,int r);
void merge(int* arr, int p, int q, int r);