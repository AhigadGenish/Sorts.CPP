#include "BubbleSort.h"
#include "QuickSort.h"
#include "InsertionSort.h"
#include "MergeSort.h"
class MinMax {
	int _min;
	int _max;
public:
	int getMin() const {
		return this->_min;
	}
	int getMax() const {
		return this->_max;
	}
	void setMin(int min);
	void setMax(int max);
	void printMinMax() const;
};
class Arr {

	int _n;
	int* _arr;
public:

	int* getArr() const {
		return this->_arr;
	}
	int getN() const
	{
		return this->_n;
	}
	int getIndex(int i) const
	{
		if (i >= 0 && i < this->getN())
			return this->_arr[i];
		else return -1;
	}
	void setIndex(int i ,int element);
	void insertionSortArr();
	void printArr() const;
	Arr(const Arr& arr);
	Arr(int n);
	~Arr();
};
class Mat {

	int _m;
	int _n;
	int** _mat;

public:

	int** getMat() const {
		return this->_mat;
	}
	int getM() const
	{
		return this->_m;
	}
	int getN() const
	{
		return this->_n;
	}
	int getIndex(int i,int j) const
	{
		if (i >= 0 && i < this->getM() && j >= 0 && j < this->getN())
			return _mat[i][j];
		else return -1;
	}
	void setIndex(int i,int j, int element);
	void printMat() const;
	void insertionSortMat(int i);
	Mat(int m,int n);
	~Mat();
};
// return the max and min of array 
MinMax minMax(int* arr,int n);   
//return the statisticOrder the k in O(n) in excepted but worst case O(n^2)
int randomizedSelect(int* arr, int p, int r, int k);   
// return the statisticOrder the k in O(n)
int select(Arr arr,int n, int k);    
