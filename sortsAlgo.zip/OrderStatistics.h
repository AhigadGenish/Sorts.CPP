#include "BubbleSort.h"
#include "QuickSort.h"
#include "InsertionSort.h"
#include "MergeSort.h"
#include "Matrix.h"
#include "minMax.h"
// return the max and min of array 
minMax minandMax(int* arr,int n);   
//return the statisticOrder the k in O(n) in excepted but worst case O(n^2)
int randomizedSelect(int* arr, int p, int r, int k);   
// return the statisticOrder the k in O(n)
int select(Array arr,int n, int k);    
int findMissElement(int* arr, int n);
Array returnFunc();
void kDividersSelect(Array arr, int n, int  k, int N);
