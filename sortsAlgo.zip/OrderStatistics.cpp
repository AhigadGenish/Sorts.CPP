#include "OrderStatistics.h"

void MinMax :: setMin(int min) {
	this->_min = min;
}
void MinMax:: setMax(int max) {
	this->_max = max;
}
void MinMax::printMinMax() const
{
	cout << "the min :" << this->getMin() << endl;
	cout << "the max :" << this->getMax() << endl;
}



MinMax minMax(int* arr , int n)
{
	int x, y;
	MinMax temp;
	if (n % 2 == 0)
	{
		if (arr[0] < arr[1])
		{
			temp.setMin(arr[0]);
			temp.setMax(arr[1]);
		}
		else
		{
			temp.setMin(arr[1]);
			temp.setMax(arr[0]);
		}

		for (int i = 1;i < (n/2);i++)
		{

			if (arr[2 * i ] < arr[2 * i + 1]){
			
				x = arr[2 * i];
				y = arr[2 * i + 1];
			}
			else {
				y = arr[2 * i];
				x = arr[2 * i + 1];
			}
			if (x < temp.getMin())
				temp.setMin(x);
			if (y > temp.getMax())
				temp.setMax(y);
			
		}

	}
	else
	{
		temp.setMin(arr[0]);
		temp.setMax(arr[0]);
		int p = (n - 1) / 2;
		for (int i = 1;i <= p;i++)
		{

			if (arr[2 * i - 1] < arr[2 * i ]) {

				x = arr[2 * i - 1];
				y = arr[2 * i];
			}
			else {
				y = arr[2 * i - 1];
				x = arr[2 * i];
			}
			if (x < temp.getMin())
				temp.setMin(x);
			if (y > temp.getMax())
				temp.setMax(y);

		}
	}


	return temp;
}
int findMissElement(int* arr, int n) {
	int sum = 0;
	int miss = 0;
	int x, y;
	MinMax temp;

		if (n % 2 == 0)
		{
			if (arr[0] < arr[1])
			{
				temp.setMin(arr[0]);
				temp.setMax(arr[1]);
			}
			else
			{
				temp.setMin(arr[1]);
				temp.setMax(arr[0]);
			}

			for (int i = 0;i < (n / 2);i++)
			{
				sum += arr[2 * i] + arr[2 * i + 1];
				if (arr[2 * i] < arr[2 * i + 1]) {

					x = arr[2 * i];
					y = arr[2 * i + 1];
				}
				else {
					y = arr[2 * i];
					x = arr[2 * i + 1];
				}
				if (x < temp.getMin())
					temp.setMin(x);
				if (y > temp.getMax())
					temp.setMax(y);

			}

		}
		else
		{
			sum = arr[0];
			temp.setMin(arr[0]);
			temp.setMax(arr[0]);
			int p = (n - 1) / 2;
			for (int i = 1;i <= p;i++)
			{
				sum += arr[2 * i - 1] + arr[2 * i ];
				if (arr[2 * i - 1] < arr[2 * i]) {

					x = arr[2 * i - 1];
					y = arr[2 * i];
				}
				else {
					y = arr[2 * i - 1];
					x = arr[2 * i];
				}
				if (x < temp.getMin())
					temp.setMin(x);
				if (y > temp.getMax())
					temp.setMax(y);

			}
		}
		miss = (((temp.getMax() + temp.getMin())* (n+1))/ 2) - sum;

		return miss;

}
// Arr
void Arr::setIndex(int i,int element) {
	if(this->getIndex(i) != -1)
		this->_arr[i] = element;
}
void Arr:: insertionSortArr()
{
	int key, j;
	for (int i = 1;i < _n;i++)
	{
		key = _arr[i];
		j = i - 1;
		while (j >= 0 && _arr[j] > key)
		{
			_arr[j + 1] = _arr[j];
			j -= 1;
		}
		_arr[j + 1] = key;
	}

	return;
}
Arr::Arr(const Arr& arr)
{
	this->_n = arr.getN();
	this->_arr = new int[this->getN()];
	for (int i = 0;i < this->getN();i++)
		this->setIndex(i, arr.getIndex(i));

}
Arr:: Arr(int n)
{
	this->_n = n;
	this->_arr = new int[n];
	for (int i = 0; i < n;i++)
		this->_arr[i] = 0;
}
void Arr::printArr() const
{
	for (int i = 0;i < this->getN();i++)
		cout << this->getIndex(i) << endl;
}
Arr::~Arr()
{
	if (this->getArr() != NULL)
		delete[] this->_arr;
}
// Matrix
void Mat :: setIndex(int i, int j, int element)
{
	
		this->_mat[i][j] = element;
}
void Mat:: printMat() const
{
	for (int i = 0;i < this->getM();i++)
	{
		for (int j = 0;j < this->getN();j++)
			cout << this->getIndex(i, j);
		cout << endl;
		
	}


}
void Mat:: insertionSortMat(int i)
{
	int key, j;
	for (int k = 1;k < this->_n;k++)
	{
		key = this->_mat[i][k];
		j = k - 1;
		while (j >= 0 && this->_mat[j][i] > key)
		{
			this->_mat[i][j+1] = this->_mat[i][j];
			j -= 1;
		}
		this->_mat[i][j+1] = key;
	}

	return;

}
Mat:: Mat(int m,int n)
{
	this->_m = m;
	this->_n = n;
	this->_mat = new int* [m];
	for (int i = 0;i < m;i++)
		this->_mat[i] = new int[n];
	for (int i = 0;i < m;i++)
		for (int j = 0;j <n;j++)
			this->setIndex(i, j, 0);
}
Mat:: ~Mat()
{
	if (this->getMat() != NULL)
	{
		for (int i = 0;i < this->getM();i++)
			delete[] this->_mat[i];
		delete[] this->_mat;
	}

}
 

// functions


int randomizedSelect(int* arr,int p,int r, int k)
{
	if (p == r)
		return arr[p];
	int q = randomizedPartition(arr, p, r);
	int j = q - p + 1;
	if (k == j)
		return arr[q];
	else if (k < j)
		return randomizedSelect(arr, p, q-1, k);
	else
		return randomizedSelect(arr, q+1, r, k - j);


}

int select(Arr arr, int n , int k)
{
	


	if (n <= 140)
	{
		arr.insertionSortArr();
		return arr.getIndex(k - 1);
	}
	else{
		
		int l = 0, r = 0;
		int i = 0;
		int counterSmaller = 0;
		int counterBigger = 0;
		int x = 0;
		int b = (n + 1) / (5);
		Arr median(b);
		Mat temp(b, 5);
		

	
		for(int j=0;j < b && i<n;j++)                    // split to fives
			for (int k = 0;k < 5 ;k++)
			{
				temp.setIndex(j, k, arr.getIndex(i));
				i++;
			}
		 
		

		for (int i = 0;i < b;i++)
			temp.insertionSortMat(i);
	
		for (int i = 0;i < b;i++)
			median.setIndex(i, temp.getIndex(i, 2));

		
	
		x = select(median, b, (b / 2));

		for (int i = 0;i < n;i++)
		{
			if (x <= arr.getIndex(i))
				counterBigger++;
			else
				counterSmaller++;
		}
		Arr arrLeft(counterSmaller);
		Arr arrRight(counterBigger);
	
		for (int i = 0 ;i < n;i++)
		{
			if (x <= arr.getIndex(i)) {
				arrRight.setIndex(r, arr.getIndex(i));
				r++;
			}
			else {
				arrLeft.setIndex(l, arr.getIndex(i));
				l++;
			}
		}

		if (k <= counterSmaller)
			return select(arrLeft,counterSmaller, k);
		else
			return select(arrRight, counterBigger, k - counterSmaller);
	}

}