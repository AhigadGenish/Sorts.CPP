#include "OrderStatistics.h"



minMax minandMax(int* arr , int n)
{
	int x, y;
	minMax temp;
	if (n % 2 == 0)
	{
		if (arr[0] < arr[1])
		{
			temp.setMin(arr[0]);
			temp.setMax(arr[1]);
		}
		else
		{
			temp.setMin(arr[1]);
			temp.setMax(arr[0]);
		}

		for (int i = 1;i < (n/2);i++)
		{

			if (arr[2 * i ] < arr[2 * i + 1]){
			
				x = arr[2 * i];
				y = arr[2 * i + 1];
			}
			else {
				y = arr[2 * i];
				x = arr[2 * i + 1];
			}
			if (x < temp.getMin())
				temp.setMin(x);
			if (y > temp.getMax())
				temp.setMax(y);
			
		}

	}
	else
	{
		temp.setMin(arr[0]);
		temp.setMax(arr[0]);
		int p = (n - 1) / 2;
		for (int i = 1;i <= p;i++)
		{

			if (arr[2 * i - 1] < arr[2 * i ]) {

				x = arr[2 * i - 1];
				y = arr[2 * i];
			}
			else {
				y = arr[2 * i - 1];
				x = arr[2 * i];
			}
			if (x < temp.getMin())
				temp.setMin(x);
			if (y > temp.getMax())
				temp.setMax(y);

		}
	}


	return temp;
}
int findMissElement(int* arr, int n) {
	int sum = 0;
	int miss = 0;
	int x, y;
	minMax temp;

		if (n % 2 == 0)
		{
			if (arr[0] < arr[1])
			{
				temp.setMin(arr[0]);
				temp.setMax(arr[1]);
			}
			else
			{
				temp.setMin(arr[1]);
				temp.setMax(arr[0]);
			}

			for (int i = 0;i < (n / 2);i++)
			{
				sum += arr[2 * i] + arr[2 * i + 1];
				if (arr[2 * i] < arr[2 * i + 1]) {

					x = arr[2 * i];
					y = arr[2 * i + 1];
				}
				else {
					y = arr[2 * i];
					x = arr[2 * i + 1];
				}
				if (x < temp.getMin())
					temp.setMin(x);
				if (y > temp.getMax())
					temp.setMax(y);

			}

		}
		else
		{
			sum = arr[0];
			temp.setMin(arr[0]);
			temp.setMax(arr[0]);
			int p = (n - 1) / 2;
			for (int i = 1;i <= p;i++)
			{
				sum += arr[2 * i - 1] + arr[2 * i ];
				if (arr[2 * i - 1] < arr[2 * i]) {

					x = arr[2 * i - 1];
					y = arr[2 * i];
				}
				else {
					y = arr[2 * i - 1];
					x = arr[2 * i];
				}
				if (x < temp.getMin())
					temp.setMin(x);
				if (y > temp.getMax())
					temp.setMax(y);

			}
		}
		miss = (((temp.getMax() + temp.getMin())* (n+1))/ 2) - sum;

		return miss;

}




int randomizedSelect(int* arr,int p,int r, int k)
{
	if (p == r)
		return arr[p];
	int q = randomizedPartition(arr, p, r);
	int j = q - p + 1;
	if (k == j)
		return arr[q];
	else if (k < j)
		return randomizedSelect(arr, p, q-1, k);
	else
		return randomizedSelect(arr, q+1, r, k - j);


}

Array kDividers;
Array returnFunc() {
	return kDividers;
}
// N is the  first n/K 
// n is the size of the current array in the recursion call
// arr is the current array in the recursion call
// k is the current divider in recursion call
void kDividersSelect(Array arr, int n, int  k,int N) {

	
	if (arr.getN() <=  2*N) {

		kDividers.append(select(arr, n, (n / 2)));
	}
	else {
		int x = select(arr, n, (n / 2));
		kDividers.append(x);
		Array arrLeft;
		Array arrRight;

		for (int j = 0;j < n;j++)
		{
			if (x < arr.getIndex(j)) {
				arrRight.append(arr.getIndex(j));
			}
			else {
				arrLeft.append(arr.getIndex(j));
			}
		}
		kDividersSelect(arrLeft, arrLeft.getN(), k / 2, N);
		kDividersSelect(arrRight, arrRight.getN(), k / 2, N);
	}
}

int select(Array arr, int n , int k)
{
	
	if (n <= 140)
	{
		arr.insertionSortArr();
		return arr.getIndex(k-1);
	}
	else{
		
		int i = 0;
		int counterSmaller = 0;
		int counterBigger = 0;
		int x = 0;
		int b = (n + 1) / (5);
		Array median(b);
		Matrix temp(b, 5);
		
		for(int j=0;j < b && i<n;j++)                    // split to fives
			for (int k = 0;k < 5 ;k++)
			{
				temp.setIndex(j, k, arr.getIndex(i));
				i++;
			}
	
		for (int i = 0;i < b;i++)
			temp.insertionSortMat(i);
	
		for (int i = 0;i < b;i++)
			median.setIndex(i, temp.getIndex(i, 2));

		x = select(median, b, (b / 2));
		Array arrLeft;
		Array arrRight;
	
		for (int j = 0;j < n;j++)
		{
			if (x < arr.getIndex(j)) {
				arrRight.append(arr.getIndex(j));
				counterBigger++;
			}
			else {

				arrLeft.append(arr.getIndex(j));
				counterSmaller++;
			}
		}

		if (k <= counterSmaller)
			return select(arrLeft,counterSmaller, k);
		else
			return select(arrRight, counterBigger, k - counterSmaller);
	}

}