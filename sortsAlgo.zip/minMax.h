#include "QuickSort.h"
class minMax
{
		int _min;
		int _max;
	public:
		int getMin() const {
			return this->_min;
		}
		int getMax() const {
			return this->_max;
		}
		void setMin(int min);
		void setMax(int max);
		void printMinMax() const;
};
