#include "Array.h"
class Matrix {

	int _m;
	int _n;
	int** _mat;

public:

	int** getMat() const {
		return this->_mat;
	}
	int getM() const
	{
		return this->_m;
	}
	int getN() const
	{
		return this->_n;
	}
	int getIndex(int i, int j) const
	{
		if (i >= 0 && i < this->getM() && j >= 0 && j < this->getN())
			return _mat[i][j];
		else return -1;
	}
	void setIndex(int i, int j, int element);
	void printMat() const;
	void insertionSortMat(int i);

	Matrix(int m, int n);
	~Matrix();
};