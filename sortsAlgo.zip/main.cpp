#include "QuickSort.h"
#include "BubbleSort.h"
#include "InsertionSort.h"
#include "MergeSort.h"
#include "CountingSort.h"

//Ahigad Genish
//ahigad.genish@gmail.com

void printArray(int* arr, int n)
{
	for (int i = 0;i < n;i++)
		cout << arr[i] << endl;
}

int main()
{
	srand(time(0));

	int arr[200] = { 100,102,109,103,101,104,105,107,108,106,112,119,113,111,114,115,117,118,116,110,132,139,133,131,134,135,137,138,136,130,122,129,123,121,124,125,127,128,126,120,142,149,143,141,144,145,147,148,146,140,152,159,153,151,154,155,157,158,156,150,162,169,163,161,164,165,167,168,166,160,172,179,173,171,174,175,177,178,176,170,182,189,183,181,184,185,187,188,186,180,192,199,193,191,194,195,197,198,196,190,200,
		2,9,3,1,4,5,7,8,6,12,19,13,11,14,15,17,18,16,10,32,39,33,31,34,35,37,38,36,30,22,29,23,21,24,25,27,28,26,20,42,49,43,41,44,45,47,48,46,40,52,59,53,51,54,55,57,58,56,50,62,69,63,61,64,65,67,68,66,60,72,79,73,71,74,75,77,78,76,70,82,89,83,81,84,85,87,90,86,80,92,99,93,91,94,95,97,98,96,88 };
	int n = sizeof(arr) / sizeof(arr[0]);
	int i = 45;
	
	int arrConst[10] = {1,9,2,8,3,7,4,6,5,5};


	//randomizedQuickSort(arrConst, 0, 9);
	//printArray(arrConst, 10);

	Arr Oarr(200);
	for (int i = 0;i < 200;i++)
	{
		Oarr.setIndex(i, arr[i]);
	}

	//int anotherArr[] ={ 2,4,5,3,7,2,2,3,6 };
	//int otherArr[1000] = {};
	//for (int i = 0;i < 1000;i++)
	//	otherArr[i] = i + 1;
	//int l = sizeof(otherArr) / sizeof(otherArr[0]);
	//int h= sizeof(anotherArr) / sizeof(anotherArr[0]);


	//cout << findMissElement(arr,n) << endl;
	//randomizedQuickSort(arr, 0, n-1);
	//bubbleSort(arr,n);
	//insertionSort(arr, n);
	//mergeSort(arr, 0, n-1);
	//MinMax temp = minMax(arr,n);
	//temp.printMinMax();
	//cout << " the " << i << " OrderStatistics is :" << randomizedSelect(arr, 0, n - 1, i) << endl;
	cout<< " the " <<i<<" OrderStatistics is :" <<select(Oarr,  Oarr.getN() , i)<<endl;
	//countingSort(arr,n);
	//printArray(arr, n);

	
	return 0;
}
