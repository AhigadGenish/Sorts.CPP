#include "CountingSort.h"

void countingSort(int* arr, int n)
{
	MinMax max = minMax(arr, n);
	int maxIndex = max.getMax();
	int* tempArr = new int[maxIndex+1];
	int* sortedArr = new int[n];
	for (int i = 0;i <= maxIndex;i++)
		tempArr[i] = 0;
	for (int j = 0; j < n;j++)
		tempArr[arr[j]] +=1;
	for (int k = 1;k <= maxIndex;k++)
		tempArr[k] += tempArr[k- 1];
	for (int i = 0;i < n;i++) {
		sortedArr[tempArr[arr[i]]-1] = arr[i];
		tempArr[arr[i]]--;
	}
	for (int j = 0;j < n;j++)
		arr[j] = sortedArr[j];

	delete[] tempArr;
	delete[] sortedArr;

	return;
}