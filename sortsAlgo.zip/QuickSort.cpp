#include "QuickSort.h"
void swapElements(int* a, int* b)
{
	int temp = *a;
	*a = *b;
	*b = temp;
}

int partition(int* arr, int p, int r)
{

	int pivot = arr[r];
	int i = p - 1;
	for (int j = p;j < r;j++)
	{
		if (arr[j] < pivot)
		{
			i += 1;
			swapElements(&arr[i], &arr[j]);
		}
	}
	swapElements(&arr[i + 1], &arr[r]);
	return i + 1;



}
int randomizedPartition(int* arr, int p, int r)
{
	int i = (rand() % (abs(r - p) + 1)) + p;
	swapElements(&arr[i], &arr[r]);
	return partition(arr, p, r);
}


void randomizedQuickSort(int* arr, int p, int r)
{
	int q;
	if (p < r)
	{
		q = randomizedPartition(arr, p, r);
		randomizedQuickSort(arr, p, q - 1);
		randomizedQuickSort(arr, q + 1, r);
	}
}