#include "minMax.h"

void minMax::setMin(int min) {
	this->_min = min;
}
void minMax::setMax(int max) {
	this->_max = max;
}
void minMax::printMinMax() const
{
	cout << "the min :" << this->getMin() << endl;
	cout << "the max :" << this->getMax() << endl;
}