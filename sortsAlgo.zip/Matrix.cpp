#include "Matrix.h"
void Matrix::setIndex(int i, int j, int element)
{

	this->_mat[i][j] = element;
}
void Matrix::printMat() const
{
	for (int i = 0;i < this->getM();i++)
	{
		for (int j = 0;j < this->getN();j++)
			cout << this->getIndex(i, j);
		cout << endl;

	}


}
void Matrix::insertionSortMat(int i)
{
	int key, j;
	for (int k = 1;k < this->_n;k++)
	{
		key = this->_mat[i][k];
		j = k - 1;
		while (j >= 0 && this->_mat[j][i] > key)
		{
			this->_mat[i][j + 1] = this->_mat[i][j];
			j -= 1;
		}
		this->_mat[i][j + 1] = key;
	}

	return;

}
Matrix:: Matrix(int m, int n)
{
	this->_m = m;
	this->_n = n;
	this->_mat = new int* [m];
	for (int i = 0;i < m;i++)
		this->_mat[i] = new int[n];
	for (int i = 0;i < m;i++)
		for (int j = 0;j < n;j++)
			this->setIndex(i, j, 0);
}
Matrix:: ~Matrix()
{
	if (this->getMat() != NULL)
	{
		for (int i = 0;i < this->getM();i++)
			delete[] this->_mat[i];
		delete[] this->_mat;
	}

}