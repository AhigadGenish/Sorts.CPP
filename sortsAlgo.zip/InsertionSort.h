#include "BubbleSort.h"
#include "QuickSort.h"

void insertionSort(int* arr, int n);