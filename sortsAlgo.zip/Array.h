#include "BubbleSort.h"
#include "QuickSort.h"
#include "InsertionSort.h"
#include "MergeSort.h"
class Array{

	int _n;
	int* _arr;
public:

	int* getArr() const {
		return this->_arr;
	}
	int getN() const
	{
		return this->_n;
	}
	int getIndex(int i) const
	{
		if (i >= 0 && i < this->getN())
			return this->_arr[i];
		else return -1;
	}
	void setIndex(int i, int element);
	void setN(int n);
	void insertionSortArr();
	void printArr() const;
	Array& operator= (const Array& other);
	void append(int x);
	Array(const Array& arr);
	Array(int n = 0);
	~Array();
};

